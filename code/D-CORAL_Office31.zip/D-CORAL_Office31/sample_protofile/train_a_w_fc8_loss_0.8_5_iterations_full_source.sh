#!/bin/bash

./build/tools/caffe train -gpu 0 -solver examples/office31/a_w_solver_coral_fc8_loss_0.8_full_source.prototxt -weights models/bvlc_reference_caffenet/bvlc_reference_caffenet.caffemodel 2>&1 | tee examples/office31/log_office31/coral_a_w_log_fc8_loss_0.8_full_source_iter_1.txt
./build/tools/caffe train -gpu 0 -solver examples/office31/a_w_solver_coral_fc8_loss_0.8_full_source.prototxt -weights models/bvlc_reference_caffenet/bvlc_reference_caffenet.caffemodel 2>&1 | tee examples/office31/log_office31/coral_a_w_log_fc8_loss_0.8_full_source_iter_2.txt
./build/tools/caffe train -gpu 0 -solver examples/office31/a_w_solver_coral_fc8_loss_0.8_full_source.prototxt -weights models/bvlc_reference_caffenet/bvlc_reference_caffenet.caffemodel 2>&1 | tee examples/office31/log_office31/coral_a_w_log_fc8_loss_0.8_full_source_iter_3.txt
./build/tools/caffe train -gpu 0 -solver examples/office31/a_w_solver_coral_fc8_loss_0.8_full_source.prototxt -weights models/bvlc_reference_caffenet/bvlc_reference_caffenet.caffemodel 2>&1 | tee examples/office31/log_office31/coral_a_w_log_fc8_loss_0.8_full_source_iter_4.txt
./build/tools/caffe train -gpu 0 -solver examples/office31/a_w_solver_coral_fc8_loss_0.8_full_source.prototxt -weights models/bvlc_reference_caffenet/bvlc_reference_caffenet.caffemodel 2>&1 | tee examples/office31/log_office31/coral_a_w_log_fc8_loss_0.8_full_source_iter_5.txt
