
% domains: 'amazon', 'dslr', 'webcam', 'Caltech10';

Ex_CORAL('dslr', 'amazon')
Ex_CORAL('dslr', 'webcam')
Ex_CORAL('dslr', 'Caltech10')

Ex_CORAL('amazon', 'webcam')
Ex_CORAL('amazon', 'dslr')
Ex_CORAL('amazon', 'Caltech10')

Ex_CORAL('webcam', 'amazon')
Ex_CORAL('webcam', 'dslr')
Ex_CORAL('webcam', 'Caltech10')

Ex_CORAL('Caltech10', 'amazon')
Ex_CORAL('Caltech10', 'webcam')
Ex_CORAL('Caltech10', 'dslr')
